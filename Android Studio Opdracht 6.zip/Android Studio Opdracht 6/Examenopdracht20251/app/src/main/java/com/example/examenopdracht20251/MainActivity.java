package com.example.examenopdracht20251;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private SQLiteDatabase gebruikersDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Database openen of aanmaken
        gebruikersDB = this.openOrCreateDatabase("gebruikersDB", MODE_PRIVATE, null);

        // Controleer of database en tabel bestaan
        File dbFile = getDatabasePath("gebruikersDB");
        if (!dbFile.exists()) {
            Log.i("database", "Database wordt aangemaakt...");
        } else {
            Log.i("database", "Database bestaat al.");
        }

        // Maak de tabel als die niet bestaat
        gebruikersDB.execSQL("CREATE TABLE IF NOT EXISTS gegevens (inlognaam VARCHAR PRIMARY KEY, wachtwoord VARCHAR);");
    }

    public void onClick(View view) {
        EditText username = findViewById(R.id.etInlognaam);
        EditText password = findViewById(R.id.etWachtwoord);
        String gebruiker = username.getText().toString().trim();
        String ww = password.getText().toString().trim();

        if (gebruiker.isEmpty() || ww.isEmpty()) {
            Toast.makeText(this, "Vul alle velden in!", Toast.LENGTH_SHORT).show();
            return;
        }

        switch (view.getId()) {
            case R.id.registreren:
                registreerGebruiker(gebruiker, ww);
                break;

            case R.id.inloggen:
                loginGebruiker(gebruiker, ww);
                break;
        }
    }

    private void registreerGebruiker(String gebruiker, String ww) {
        try {
            // Voeg de gebruiker toe aan de database
            String sql = "INSERT OR REPLACE INTO gegevens (inlognaam, wachtwoord) VALUES (?, ?);";
            gebruikersDB.execSQL(sql, new String[]{gebruiker, ww});
            Toast.makeText(this, "Registratie succesvol", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Gebruiker kon niet geregistreerd worden.", Toast.LENGTH_SHORT).show();
        }
    }

    private void loginGebruiker(String gebruiker, String ww) {
        try {
            // Controleer de ingevoerde gegevens
            String query = "SELECT wachtwoord FROM gegevens WHERE inlognaam = ?";
            Cursor cursor = gebruikersDB.rawQuery(query, new String[]{gebruiker});

            if (cursor != null && cursor.moveToFirst()) {
                String storedPassword = cursor.getString(0);
                if (storedPassword.equals(ww)) {
                    Toast.makeText(this, "Inloggen succesvol", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(this, MainActivity2.class);
                    intent.putExtra("username", gebruiker); // Gebruikersnaam doorsturen
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Fout wachtwoord", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Gebruiker niet gevonden", Toast.LENGTH_SHORT).show();
            }

            if (cursor != null) cursor.close();
        } catch (Exception e) {
            Toast.makeText(this, "Fout bij inloggen: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}

