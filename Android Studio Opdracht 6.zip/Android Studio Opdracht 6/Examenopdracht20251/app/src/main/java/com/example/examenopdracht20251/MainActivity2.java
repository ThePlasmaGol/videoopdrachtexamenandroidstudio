package com.example.examenopdracht20251;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log; // Voor debugging
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity {

    EditText etCity, etCountry;
    TextView tvResult, tvWelcome;
    private final String url = "https://api.openweathermap.org/data/2.5/weather";
    private final String appid = "2623c59a6dde87adee7fce1879c0a6ac"; // Zorg dat de API-key correct is
    DecimalFormat df = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Initialiseer views
        etCity = findViewById(R.id.etCity);
        etCountry = findViewById(R.id.etCountry);
        tvResult = findViewById(R.id.tvResult);
        tvWelcome = findViewById(R.id.tvWelcome);

        // Haal de gebruikersnaam op uit de intent
        String username = getIntent().getStringExtra("username");
        if (username != null) {
            tvWelcome.setText("Welkom, " + username + "!");
        }
    }

    public void getWeatherDetails(View view) {
        String tempUrl = "";
        String city = etCity.getText().toString().trim();
        String country = etCountry.getText().toString().trim();

        if (city.isEmpty()) {
            tvResult.setText("Vul een stad in!");
        } else {
            // Genereer de URL
            tempUrl = country.isEmpty() ?
                    url + "?q=" + city + "&appid=" + appid :
                    url + "?q=" + city + "," + country + "&appid=" + appid;

            // Log de URL voor debugging
            Log.d("WeatherApp", "API URL: " + tempUrl);

            StringRequest stringRequest = new StringRequest(Request.Method.GET, tempUrl, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    // Log de volledige API-respons voor debugging
                    Log.d("WeatherApp", "API Response: " + response);

                    try {
                        // Verwerk JSON-response
                        JSONObject jsonResponse = new JSONObject(response);

                        // Controleer of de nodige data aanwezig is
                        if (!jsonResponse.has("weather") || !jsonResponse.has("main")) {
                            tvResult.setText("Geen weergegevens gevonden voor de opgegeven stad.");
                            return;
                        }

                        JSONArray jsonArray = jsonResponse.getJSONArray("weather");
                        JSONObject jsonObjectWeather = jsonArray.getJSONObject(0);
                        String description = jsonObjectWeather.getString("description");

                        JSONObject jsonObjectMain = jsonResponse.getJSONObject("main");
                        double temp = jsonObjectMain.getDouble("temp") - 273.15;
                        double feelsLike = jsonObjectMain.getDouble("feels_like") - 273.15;
                        int pressure = jsonObjectMain.getInt("pressure");
                        int humidity = jsonObjectMain.getInt("humidity");

                        String wind = jsonResponse.getJSONObject("wind").getString("speed");
                        String clouds = jsonResponse.getJSONObject("clouds").getString("all");
                        String countryName = jsonResponse.getJSONObject("sys").getString("country");
                        String cityName = jsonResponse.getString("name");

                        // Toon resultaten op het scherm
                        tvResult.setTextColor(Color.BLACK); // De tekstkleur wordt nu zwart
                        String output = "Weer in " + cityName + " (" + countryName + "):\n"
                                + "Temperatuur: " + df.format(temp) + "°C\n"
                                + "Voelt als: " + df.format(feelsLike) + "°C\n"
                                + "Vochtigheid: " + humidity + "%\n"
                                + "Beschrijving: " + description + "\n"
                                + "Wind snelheid: " + wind + " m/s\n"
                                + "Bewolking: " + clouds + "%\n"
                                + "Luchtdruk: " + pressure + " hPa";
                        tvResult.setText(output);
                    } catch (JSONException e) {
                        Log.e("WeatherApp", "JSON Fout: " + e.getMessage());
                        Toast.makeText(MainActivity2.this, "Fout bij verwerken JSON: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Log de fout
                    Log.e("WeatherApp", "Volley Fout: " + error.toString());
                    Toast.makeText(MainActivity2.this, "Fout bij ophalen weergegevens! Controleer je internetverbinding of stadnaam.", Toast.LENGTH_SHORT).show();
                }
            });

            // Voeg verzoek toe aan de wachtrij
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }
    }
}
